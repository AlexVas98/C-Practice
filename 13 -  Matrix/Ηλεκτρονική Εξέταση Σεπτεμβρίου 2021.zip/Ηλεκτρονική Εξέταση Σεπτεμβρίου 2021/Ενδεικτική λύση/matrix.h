#pragma once

#include <vector>
#include <exception>
#include <algorithm>
#include <string>

#include "matrix_exceptions.h"

// Dual implementation. Uncomment the line below to enable the std::vector<> implementation.

//#define VECTOR_IMPLEMENTATION

namespace math
{
#ifndef VECTOR_IMPLEMENTATION
	template <typename S> class matrix
	{
		unsigned int cols, rows;
		S * data;
	public:
		matrix(unsigned int rows, unsigned int cols)
			: rows(rows), cols(cols)
		{
			data = new S[cols*rows];
			memset(data, 0, cols*rows * sizeof(S));
		}

		~matrix()
		{
			if (data)
			{
				delete[] data;
				data = nullptr;
			}
		}

		std::pair<unsigned int, unsigned int> size() const
		{
			return std::pair<unsigned int, unsigned int>(rows, cols);
		}

		const S & operator () (unsigned int row, unsigned int col) const
		{
			if (row >= rows || col >= cols)
				throw out_of_bounds_exception();

			return data[cols*row + col];
		}

		S & operator () (unsigned int row, unsigned int col)
		{
			if (row >= rows || col >= cols)
				throw out_of_bounds_exception();

			return data[cols*row + col];
		}

		unsigned int count_non_zero() const
		{
			const S zero = S();
			unsigned int count = 0;
			for (unsigned int k = 0; k<rows*cols; k++)
			{
				if (data[k] != zero)
					count++;
			}
			return count;
		}

		unsigned int count_zero() const
		{
			const S zero = S();
			unsigned int count = 0;
			for (unsigned int k = 0; k < rows*cols; k++)
			{
				if (data[k] == zero)
					count++;
			}
			return count;
		}

		matrix<S> * get_row(unsigned int r)
		{
			if (r >= rows)
			{
				throw out_of_bounds_exception();
			}
			matrix<S> * result = new matrix<S>(1, cols);
			for (unsigned int j = 0; j < cols; j++)
			{
				(*result)(0, j) = operator()(r, j);
			}
			return result;
		}

		matrix<S> * get_column(unsigned int c)
		{
			if (c >= cols)
			{
				throw out_of_bounds_exception();
			}
			matrix<S> * result = new matrix<S>(rows, 1);
			for (unsigned int i = 0; i < rows; i++)
			{
				(*result)(i, 0) = operator()(i, c);
			}
			return result;
		}

		matrix<S> & operator = (const matrix<S> & right)
		{
			if (this == &right)
				return *this;
			// Allocate memory only if necessary
			if (cols*rows != right.cols*right.rows || !data)
			{
				cols = right.cols;
				rows = right.rows;
				if (data)
					delete[] data;
				data = new S[rows*cols];
			}
			
			memcpy (data, right.data, rows*cols*sizeof(S));
			return *this;
		}

		matrix(const matrix<S> & right)
			: cols(right.cols), rows(right.rows)
		{
			data = new S[rows*cols];
			memcpy(data, right.data, rows*cols * sizeof(S));
		}
				
		matrix<S> operator + (const matrix<S> & right) const 
		{
			std::pair<unsigned int, unsigned int> right_sz = right.size();
			if (right_sz.first != rows || right_sz.second != cols)
			{
				// abort and throw exception
				throw incompatible_matrix_exception();
			}

			matrix<S> result = matrix<S>(rows, cols);

			for (unsigned int i = 0; i < rows; i++)
				for (unsigned int j = 0; j < cols; j++)
				{
					result(i, j) = operator()(i, j) + right(i, j);
				}

			return result;
		}

		matrix<S> operator - (const matrix<S> & right) const
		{
			std::pair<unsigned int, unsigned int> right_sz = right.size();
			if (right_sz.first != rows || right_sz.second != cols)
			{
				// abort and throw exception
				throw incompatible_matrix_exception();
			}

			matrix<S> result = matrix<S>(rows, cols);

			for (unsigned int i = 0; i < rows; i++)
				for (unsigned int j = 0; j < cols; j++)
				{
					result(i, j) = operator()(i, j) - right(i, j);
				}

			return result;
		}

		matrix<S> operator * (const matrix<S> & right) const 
		{
			unsigned int left_cols = size().second;
			unsigned int right_rows = right.size().first;
			if (left_cols != right_rows)
				// if the cols of the left matrix differ from the rows of the second matrix
			{
				// abort and throw exception
				throw incompatible_matrix_exception();
			}

			unsigned int left_rows = size().first;
			unsigned int right_cols = right.size().second;

			matrix<S> result = matrix<S>(left_rows, right_cols);

			for (unsigned int i = 0; i < left_rows; i++)
				for (unsigned int j = 0; j < right_cols; j++)
				{
					for (unsigned int k = 0; k < left_cols; k++)
						result(i, j) += operator()(i, k)*right(k, j);
				}

			return result;
		}
	};

#else

template <typename S> class matrix
	{
		unsigned int cols, rows;
		std::vector<S> data;

	public:
		matrix(unsigned int rows, unsigned int cols)
			: rows(rows), cols(cols)
		{
			data.resize(rows * cols, S());
		}

		std::pair<unsigned int, unsigned int> size() const
		{
			return std::pair<unsigned int, unsigned int>(rows, cols);
		}
		
		const S & operator () (unsigned int row, unsigned int col) const
		{
			if (row >= rows || col >= cols)
				throw out_of_bounds_exception();

			return data[cols*row + col];
		}
		
		S & operator () (unsigned int row, unsigned int col)
		{
			if (row >= rows || col >= cols)
				throw out_of_bounds_exception();

			return data[cols*row + col];
		}

		unsigned int count_non_zero() const
		{
			const S zero = S();
			unsigned int count = 0;
			for (S item : data)
			{
				if (item != zero)
					count++;
			}
			return count;
		}

		unsigned int count_zero() const
		{
			const S zero = S();
			unsigned int count = 0;
			for (S item : data)
			{
				if (item == zero)
					count++;
			}
			return count;
		}

		matrix<S> * get_row(unsigned int r)
		{
			if (r >= rows)
			{
				throw out_of_bounds_exception();
			}
			matrix<S> * result = new matrix<S>(1, cols);
			for (unsigned int j = 0; j < cols; j++)
			{
				(*result)(0, j) = operator()(r, j);
			}
			return result;
		}

		matrix<S> * get_column(unsigned int c)
		{
			if (c >= cols)
			{
				throw out_of_bounds_exception();
			}
			matrix<S> * result = new matrix<S>(rows, 1);
			for (unsigned int i = 0; i < rows; i++)
			{
				(*result)(i, 0) = operator()(i, c);
			}
			return result;
		}

        /*
		// Note: Not neccesary to define the operator. It only performs shallow member copy.

		matrix<S> & operator = (const matrix<S> & right)
		{
			data = right.data;
			cols = right.cols;
			rows = right.rows;
			return *this;
		}
		*/

		/*
		// Note: Not neccesary to define the ctor. It only performs shallow member copy.

		matrix(const matrix<S> & right)
			: data(right.data), cols(right.cols), rows(right.rows)
		{
		}
		*/
		
		matrix<S> operator + (const matrix<S> & right) const 
		{
			std::pair<unsigned int, unsigned int> right_sz = right.size();
			if (right_sz.first != rows || right_sz.second != cols)
			{
				// abort and throw exception
				throw incompatible_matrix_exception();
			}

			matrix<S> result = matrix<S>(rows, cols);

			for (unsigned int i = 0; i < rows; i++)
				for (unsigned int j = 0; j < cols; j++)
				{
					result(i, j) = operator()(i, j) + right(i, j);
				}

			return result;
		}

		matrix<S> operator - (const matrix<S> & right) const
		{
			std::pair<unsigned int, unsigned int> right_sz = right.size();
			if (right_sz.first != rows || right_sz.second != cols)
			{
				// abort and throw exception
				throw incompatible_matrix_exception();
			}

			matrix<S> result = matrix<S>(rows, cols);

			for (unsigned int i = 0; i < rows; i++)
				for (unsigned int j = 0; j < cols; j++)
				{
					result(i, j) = operator()(i, j) - right(i, j);
				}

			return result;
		}

		matrix<S> operator * (const matrix<S> & right) const 
		{
			unsigned int left_cols = size().second;
			unsigned int right_rows = right.size().first;
			if (left_cols != right_rows)
				// if the cols of the left matrix differ from the rows of the second matrix
			{
				// abort and throw exception
				throw incompatible_matrix_exception();
			}

			unsigned int left_rows = size().first;
			unsigned int right_cols = right.size().second;

			matrix<S> result = matrix<S>(left_rows, right_cols);

			for (unsigned int i = 0; i < left_rows; i++)
				for (unsigned int j = 0; j < right_cols; j++)
				{
					for (unsigned int k = 0; k < left_cols; k++)
						result(i, j) += operator()(i, k)*right(k, j);
				}

			return result;
		}
	};
#endif
}
