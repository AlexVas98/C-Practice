#pragma once

#include <stdio.h>
#include <iostream>
#include <random>
#include <set>
#include <stdlib.h>
#include <utility>
#include "matrix_printer.h"
#include "matrix.h"

bool validate(bool expr)
{
	std::cout << ((expr) ? "[PASS]\n" : "[FAIL]\n");
	return expr;
}

void validate_dimensions(const std::pair<unsigned int, unsigned int> & dims )
{
	if (!validate(dims.first == 3 && dims.second == 2))
	{
		std::cout << "Required 3 rows by 2 columns, got " <<
			dims.first << " by " << dims.second << ".\n";
	}
}

template <typename T>
math::matrix<T> * validate_heap_allocation()
{
	unsigned int cols, rows;
	std::cout << "Allocating a large matrix on the heap...                           ";
	srand(1);
	cols = rand() % 100 + 1;
	rows = rand() % 100 + 1;

	math::matrix<T> * B = new (std::nothrow) math::matrix<T>(rows, cols);
	if (!validate(B != nullptr))
	{
		std::cout << "Operator new failed to initialize matrix.\n";
	}
	return B;
}

template <typename T>
void validate_heap_deallocation(math::matrix<T> * m)
{
	if (!validate(m != nullptr))
	{
		std::cout << "Null pointer. Nothing to delete.\n";
	}
	std::cout << "(\"PASS\" does not necessarily signify a correct destructor)\n";
}

template <typename T>
void generate_nonzero_random_values(math::matrix<T> & m, unsigned int cap)
{
	std::pair<unsigned int, unsigned int> dims = m.size();
	for (unsigned int i = 0; i < dims.first; i++)
		for (unsigned int j = 0; j < dims.second; j++)
		{
			m(i, j) = (T)(1 + rand() % cap);
		}
	printf("Created a matrix with %d rows and %d columns.\n", dims.first, dims.second);
	
}

template <typename T>
void validate_copy(math::matrix<T> & source, math::matrix<T> & destination)
{
	static unsigned int tag = 90;
	std::pair<unsigned int, unsigned int> dims = source.size();

	std::cout << "Checking validity of copied elements...                            ";
	bool error = false;
	for (unsigned int i = 0; i < dims.first; i++)
		for (unsigned int j = 0; j < dims.second; j++)
		{
			if ((source(i, j) != destination(i, j)) || destination(i, j) == (T)0)
			{
				error = true;
				break;
			}
		}
	validate(!error);

	std::cout << "Checking independence of the two matrices...                       ";
	source(0, 0) = (T)(tag++);
	validate(destination(0, 0) != source(0, 0));
}

template <typename T>
math::matrix<T> create_operant_A()
{
	math::matrix<T> A(3, 2);
	A(0, 0) = (T)1;
	A(1, 0) = (T)2;
	A(2, 1) = (T)4;
	return A;
}

template <typename T>
math::matrix<T> create_operant_B()
{
	math::matrix<T> B(3, 2);
	B(0, 1) = (T)3;
	B(1, 0) = (T)2;
	B(2, 0) = (T)3;
	B(2, 1) = (T)1;
	return B;
}

template <typename T>
math::matrix<T> create_operant_D()
{
	math::matrix<T> D(2, 3);
	D(0, 0) = D(0, 1) = D(0, 2) = 2;
	return D;
}

template <typename T>
void validate_addition(math::matrix<T> & A, math::matrix<T> & B, math::matrix<T> & C)
{
	if (!validate(C(0, 0) == 1 && C(0, 1) == 3 && C(1, 0) == 4 && C(2, 0) == 3 && C(2, 1) == 5))
	{
		std::cout << "Resulting matrix is incorrect.\n";
	}

	std::cout << "\n";
	math::matrix_text<T> text(3, 79);
	text.insert(A);
	text.insert(" + ", 1);
	text.insert(B);
	text.insert(" = ", 1);
	text.insert(C);
	text.print();
	std::cout << "\n";
}

template <typename T>
void validate_multiplication(math::matrix<T> & A, math::matrix<T> & D, math::matrix<T> & C)
{
	if (!validate(C(0, 0) == 2 && C(0, 1) == 2 && C(0, 2) == 2 &&
		C(1, 0) == 4 && C(1, 1) == 4 && C(1, 2) == 4 &&
		C(2, 0) == 0 && C(2, 1) == 0 && C(2, 2) == 0))
	{
		std::cout << "Resulting matrix is incorrect.\n";
	}
	std::cout << "\n";
	math::matrix_text<T> text2(3, 79);
	text2.insert(A);
	text2.insert(" * ", 1);
	text2.insert(D);
	text2.insert(" = ", 1);
	text2.insert(C);
	text2.print();
	std::cout << "\n";
}

template <typename T>
void set_n_nonzero_elements(math::matrix<T> & M_rand, unsigned int N)
{
	std::pair<unsigned int, unsigned int> dims = M_rand.size();
	std::set<unsigned int> rand_positions;
	// generate exactly N unique matrix coordinates  
	for (unsigned int i = 0; i < N; i++)
	{
		bool collision = true;
		do
		{
			unsigned int elem = rand() % (dims.first*dims.second);
			if (rand_positions.find(elem) == rand_positions.end())
			{
				collision = false;
				rand_positions.insert(elem);
			}
		} while (collision);
	}
	// fill these matrix elements with non-zero random numbers;
	for (unsigned int elem : rand_positions)
	{
		M_rand(elem / dims.second, elem % dims.second) = (T)(1 + 99 * (rand() / (float)RAND_MAX));
	}
	std::cout << "Created a " << std::setw(2) << dims.first << " X " << std::setw(2) << dims.second << " matrix with " << N << " random elements:\n";
	math::matrix_text<T> text(dims.first, 79);
	text.insert(M_rand);
	text.print();
	std::cout << "\n";
}

template <typename T>
void validate_column(math::matrix<T> & col, unsigned int rows)
{
	std::pair<unsigned int, unsigned int> dims = col.size();
	if (!validate(dims.first == rows && dims.second == 1))
	{
		std::cout << "Incorrect column size.\n";
	}
	std::cout << "\n";
	math::matrix_text<T> text(rows, 79);
	text.insert(col);
	text.print();
	std::cout << "\n";
}
