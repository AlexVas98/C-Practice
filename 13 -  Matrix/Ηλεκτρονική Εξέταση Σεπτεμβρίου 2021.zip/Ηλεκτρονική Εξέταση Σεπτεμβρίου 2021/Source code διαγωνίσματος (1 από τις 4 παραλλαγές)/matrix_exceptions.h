#pragma once

#include <exception>

namespace math
{
	class incompatible_matrix_exception : public std::exception
	{
	public:
		const char* what() const noexcept
		{
			return "Matrix dimensions are incompatible.";
		}
	};

	class out_of_bounds_exception : public std::exception
	{
	public:
		const char* what() const noexcept
		{
			return "Matrix access outside the valid dimension range.";
		}
	};

}