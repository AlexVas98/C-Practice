#pragma once
#include <sstream>
#include <iomanip>
#include "matrix.h"
#include <string>
#include <vector>
#include <sstream>

#define PRECISION 3
#define WIDTH 6

namespace math
{
	template<typename T>
	class matrix_text
	{
		std::vector<std::string> text;
		unsigned int rows, cols;
		unsigned int cur_col;

	public: 
		matrix_text(unsigned int rows, unsigned int cols) :
			text(rows), rows(rows), cols(cols), cur_col(0)
		{
			for (std::string & line : text)
				line.resize(cols);
		}

		void insert(const matrix<T> & mat, unsigned int start_row = 0)
		{
			auto dim = mat.size();
			unsigned int copy_len;
			for (unsigned int i = 0; i < std::min<unsigned int>(dim.first,rows-start_row); i++)
			{
				std::ostringstream buf;
				buf << std::setprecision(PRECISION);
								
				buf << "[ ";
				for (unsigned int j = 0; j < dim.second; j++)
				{
					buf << std::setw(WIDTH) << std::fixed << std::right << mat(i, j) << " ";
				}
				buf << "]";
				std::string st = buf.str();
				copy_len = std::min<unsigned int>((unsigned int)st.size(), cols - cur_col - 1);
				for (unsigned int k = 0; k < copy_len; k++)
					text[i+ start_row][k + cur_col] = st[k];

			}
			cur_col += copy_len;
		}

		void insert(const std::string & txt, unsigned int start_row = 0)
		{
			unsigned int copy_len = std::min<unsigned int>((unsigned int)txt.size(), cols - cur_col - 1);
			unsigned int row = std::min<unsigned int>(start_row, rows - 1);
			for (unsigned int k = 0; k < copy_len; k++)
				text[row][k + cur_col] = txt[k];
			cur_col += copy_len;
		}

		void print()
		{
			for (auto line : text)
				std::cout << line << "\n";
		}
	};

}