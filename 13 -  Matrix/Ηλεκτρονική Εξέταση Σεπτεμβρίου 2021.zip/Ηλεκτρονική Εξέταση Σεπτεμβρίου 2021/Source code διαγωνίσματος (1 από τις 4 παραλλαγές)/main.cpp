#include "matrix.h"
#include "tests.h"

typedef float element_t;

#define ENABLE_TEST1
#define ENABLE_TEST2
#define ENABLE_TEST3
#define ENABLE_TEST4

#ifdef ENABLE_TEST1
void test_matrix_creation()
{
	std::cout << "_________________________________________________________________________\n";
	std::cout << "\nTesting matrix creation\n";
	std::cout << "_________________________________________________________________________\n\n";

	// Create a small local matrix
	std::cout << "Constructing a 3X2 matrix.\n";

	                               //  
	math::matrix<int> A(3, 2);     // TODO: Zero all elements upon creation.
	                               // 
	
	// check dimensions
	std::cout << "Checking reported matrix dimensions...                             ";
	std::pair<unsigned int, unsigned int> dimensions;

	                               // 
	dimensions = A.size();         // TODO     
	                               //

	validate_dimensions(dimensions);

	// allocating a large matrix on the heap
	// calls the only available constructor already used above.
	math::matrix<element_t> * B = validate_heap_allocation<element_t>();

	// deallocate the matrix
	std::cout << "Deleting the matrix...                                             ";
	
								   //
	if (B) delete B;			   // TODO
	                               //
	
	validate_heap_deallocation<element_t>(B);
	std::cout << "\n";
}
#endif

#ifdef ENABLE_TEST2
void test_element_queries(int seed)
{
	std::cout << "_________________________________________________________________________\n";
	std::cout << "\nTesting element queries\n";
	std::cout << "_________________________________________________________________________\n\n";

	// compute some random dimensions for the matrix
	unsigned int cols, rows;
	srand(seed);
	cols = rand() % 10 + 1;
	rows = rand() % 10 + 1;
	
	math::matrix<element_t> A(rows,cols);
	printf("Created a matrix with %d rows and %d columns.\n", rows, cols);

	// Query a random single element
	unsigned int i = rand() % rows;
	unsigned int j = rand() % cols;

										//
	element_t a_ij = A(i, j);			// TODO: A(row index, column index), index is zero-based
										//
	
	printf("Element at (%d,%d) must be zero. It is ", i, j);
	std::cout << std::setw(5) << std::setprecision(3) << a_ij << "...                      ";
	validate(a_ij == element_t());
	
	// Assign a new value to the element
	element_t val = (element_t)(50 * (rand() / (float)RAND_MAX)); 
	std::cout << "Assign and read back a random value there (" << std::setw(5) << std::setprecision(3) << val << ")...               ";
	
										//
	A(i, j) = val;						// TODO
										//
	
	if (!validate(val == A(i, j)))
	{
		std::cout << "Error: Should read back " << val << ", but got " << A(i, j) << "\n";
	}
	std::cout << "\n";

	// Create an empty matrix and assign a number of non-zero random elements
	cols = rand() % 7 + 5;
	rows = rand() % 10 + 5;
	unsigned int N = (unsigned int)(rand() % 10 + 10);
	math::matrix<element_t> M_rand(rows, cols);
	
	set_n_nonzero_elements(M_rand, N);

	unsigned int cnt;

	std::cout << "Count zero elements (should be " << std::setw(3) << rows*cols-N << ")...                             ";

								//
	cnt = M_rand.count_zero();	// TODO
								//

	if (!validate(cnt == rows*cols-N))
	{
		std::cout << "Reported " << cnt << " elements.\n";
	}

	// extract one random column and print it
	{
		unsigned int k = rand() % cols;
		std::cout << "Get column " << std::setw(2) << k << " from the matrix...                                   ";

																	//
		math::matrix<element_t> * col = M_rand.get_column(k);		// TODO (return a newly allocated column matrix)
																	//

		validate_column<element_t>(*col, rows);
		delete col;
	}

	std::cout << "\n";
}
#endif

#ifdef ENABLE_TEST3
void test_copy(unsigned int seed)
{
	std::cout << "_________________________________________________________________________\n";
	std::cout << "\nTesting copy ctor and operator =\n";
	std::cout << "_________________________________________________________________________\n\n";

	// compute some random dimensions for the matrix
	unsigned int cols, rows;
	srand(seed);
	cols = rand() % 10 + 1;
	rows = rand() % 10 + 1;

	math::matrix<element_t> A(rows, cols);

	// fill matrix with random values
	generate_nonzero_random_values(A, 80);
	std::cout << "Copy-constructing a new matrix from it.\n\n";

											//
	math::matrix<element_t> B = A;			// TODO
											//

	validate_copy<element_t>(A, B);

	std::cout << "\nPerforming copy assignment.\n\n";
	math::matrix<element_t> C(1, 1);

											//
	C = A;									// TODO
											//

	validate_copy<element_t>(A, C);
	std::cout << "\n";
}
#endif

#ifdef ENABLE_TEST4
void test_matrix_operations()
{
	std::cout << "_________________________________________________________________________\n";
	std::cout << "\nTesting some basic matrix operations\n";
	std::cout << "_________________________________________________________________________\n\n";

	math::matrix<element_t> A = create_operant_A<element_t>();
	math::matrix<element_t> B = create_operant_B<element_t>();

	std::cout << "Checking matrix addition...                                        ";

													//
	math::matrix<element_t> C = A + B;				// TODO
													//

	validate_addition(A, B, C);

	std::cout << "Checking matrix multiplication. Result should be a 3X3 matrix...   ";

	math::matrix<element_t> D = create_operant_D<element_t>();

							//
	C = A * D;				// TODO
							//

	validate_multiplication(A, D, C);
}
#endif

//------------------------------------------- main function -------------------

int main(int argc, char ** argv)
{
#ifdef ENABLE_TEST1
	test_matrix_creation();
#endif

	unsigned int seed(1000);

#ifdef ENABLE_TEST2
	test_element_queries(seed);
#endif

#ifdef ENABLE_TEST3
	test_copy(seed);
#endif

#ifdef ENABLE_TEST4
	test_matrix_operations();
#endif

	getchar();
	return 0;
}